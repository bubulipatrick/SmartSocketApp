pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

// ⭐ REQUIRED for version catalogs (fixes unresolved reference to libs)
enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")

rootProject.name = "SmartSocket"
include(":app")
