package edu.uc.sysarch32.bubuli.smartsocket

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout

class ReportsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reports)

        setupBottomButtons()
    }

    private fun setupBottomButtons() {
        val dashboardBtn = findViewById<LinearLayout>(R.id.buttonDashboard)
        val devicesBtn = findViewById<LinearLayout>(R.id.buttonDevices)
        val reportsBtn = findViewById<LinearLayout>(R.id.buttonReports)
        val profileBtn = findViewById<LinearLayout>(R.id.buttonProfile)

        dashboardBtn.setOnClickListener {
            if (this !is DashboardActivity) {
                startActivity(Intent(this, DashboardActivity::class.java))
                finish()
            }
        }
        devicesBtn.setOnClickListener {
            if (this !is DevicesActivity) {
                startActivity(Intent(this, DevicesActivity::class.java))
                finish()
            }
        }
        reportsBtn.setOnClickListener {
            if (this !is ReportsActivity) {
                startActivity(Intent(this, ReportsActivity::class.java))
                finish()
            }
        }
        profileBtn.setOnClickListener {
            if (this !is UserActivity) {
                startActivity(Intent(this, UserActivity::class.java))
                finish()
            }
        }
    }
}
