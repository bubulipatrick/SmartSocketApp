package edu.uc.sysarch32.bubuli.smartsocket

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : Activity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvGoRegister: TextView
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var auth: FirebaseAuth   // 🔥 Firebase Auth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize Database
        dbHelper = DatabaseHelper(this)

        // Initialize Firebase
        auth = FirebaseAuth.getInstance()

        // Initialize Views
        etEmail = findViewById(R.id.emailLogin)
        etPassword = findViewById(R.id.passwordLogin)
        btnLogin = findViewById(R.id.btnLogin)
        tvGoRegister = findViewById(R.id.tvGoRegister)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                loginFirebase(email, password)   // 🔥 Try Firebase first
            }
        }

        tvGoRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
            finish()
        }
    }

    // 🔥 Firebase Authentication Login
    private fun loginFirebase(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Firebase Login Successful!", Toast.LENGTH_SHORT).show()
                    goToDashboard()
                } else {
                    // If Firebase fails → fallback to SQLite
                    loginSQLite(email, password)
                }
            }
    }

    // 🗄️ SQLite Login (Fallback)
    private fun loginSQLite(email: String, password: String) {
        val db: SQLiteDatabase = dbHelper.readableDatabase

        val query = "SELECT * FROM users WHERE email = ? AND password = ?"
        val cursor = db.rawQuery(query, arrayOf(email, password))

        if (cursor.moveToFirst()) {
            Toast.makeText(this, "Local Login Successful!", Toast.LENGTH_SHORT).show()
            goToDashboard()
        } else {
            Toast.makeText(this, "Invalid Email or Password", Toast.LENGTH_SHORT).show()
        }

        cursor.close()
        db.close()
    }

    private fun goToDashboard() {
        startActivity(Intent(this, DashboardActivity::class.java))
        finish()
    }
}
