package edu.uc.sysarch32.bubuli.smartsocket

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "smartsocket.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {

        // USERS TABLE
        db?.execSQL(
            "CREATE TABLE users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "fullname TEXT," +
                    "email TEXT UNIQUE," +
                    "password TEXT)"
        )

        // DEVICES TABLE
        db?.execSQL(
            "CREATE TABLE devices (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "user_id INTEGER," +
                    "device_name TEXT," +
                    "device_type TEXT," +
                    "status TEXT," +
                    "created_at TEXT," +
                    "FOREIGN KEY(user_id) REFERENCES users(id))"
        )

        db?.execSQL(
            /* sql = */ "CREATE TABLE usage_logs (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "device_id INTEGER," +
                    "power_watts REAL," +
                    "voltage REAL," +
                    "timestamp TEXT," +
                    "FOREIGN KEY(device_id) REFERENCES devices(id))"
        )




        // ALERTS TABLE
        db?.execSQL(
            "CREATE TABLE alerts (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "device_id INTEGER," +
                    "title TEXT," +
                    "message TEXT," +
                    "timestamp TEXT," +
                    "FOREIGN KEY(device_id) REFERENCES devices(id))"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS alerts")
        db?.execSQL("DROP TABLE IF EXISTS usage_logs")
        db?.execSQL("DROP TABLE IF EXISTS devices")
        db?.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }
}
