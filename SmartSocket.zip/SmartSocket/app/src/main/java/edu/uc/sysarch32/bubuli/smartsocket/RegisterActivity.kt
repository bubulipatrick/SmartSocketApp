package edu.uc.sysarch32.bubuli.smartsocket

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest

class RegisterActivity : Activity() {

    private lateinit var etFullname: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var tvGoLogin: TextView

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        dbHelper = DatabaseHelper(this)
        auth = FirebaseAuth.getInstance()

        etFullname = findViewById(R.id.fullNameRegister)
        etEmail = findViewById(R.id.emailRegister)
        etPassword = findViewById(R.id.passwordRegister)
        etConfirmPassword = findViewById(R.id.confirmPasswordRegister)
        btnRegister = findViewById(R.id.btnRegister)
        tvGoLogin = findViewById(R.id.tvGoLogin)

        btnRegister.setOnClickListener {
            val fullname = etFullname.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val confirm = etConfirmPassword.text.toString().trim()

            when {
                fullname.isEmpty() || email.isEmpty() || password.isEmpty() || confirm.isEmpty() ->
                    toast("Please fill all fields")

                !Patterns.EMAIL_ADDRESS.matcher(email).matches() ->
                    toast("Invalid email format")

                password.length < 6 ->
                    toast("Password must be at least 6 characters")

                password != confirm ->
                    toast("Passwords do not match")

                else ->
                    registerFirebase(fullname, email, password)
            }
        }

        tvGoLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    // 🔥 Firebase Registration
    private fun registerFirebase(fullname: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                val user = auth.currentUser

                // ✅ SAVE FULL NAME TO FIREBASE PROFILE
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(fullname)
                    .build()

                user?.updateProfile(profileUpdates)?.addOnCompleteListener {
                    saveUserToSQLite(fullname, email, password)
                }
            }
            .addOnFailureListener {
                toast("Firebase Error: ${it.message}")
            }
    }

    // 🗄 Save to SQLite
    private fun saveUserToSQLite(fullname: String, email: String, password: String) {
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put("fullname", fullname)
            put("email", email)
            put("password", password)
        }

        val result = db.insert("users", null, values)

        if (result == -1L) {
            toast("SQLite Error: Email already exists")
        } else {
            toast("Registration Successful")
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        db.close()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
