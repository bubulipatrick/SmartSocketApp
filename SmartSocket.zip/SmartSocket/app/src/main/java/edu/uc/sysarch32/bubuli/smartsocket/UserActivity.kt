package edu.uc.sysarch32.bubuli.smartsocket

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.*
import com.google.firebase.auth.FirebaseAuth

class UserActivity : Activity() {

    private lateinit var auth: FirebaseAuth

    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var btnLogout: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()

        // ✅ Redirect if not logged in
        if (auth.currentUser == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_user)

        initViews()
        loadUserData()
        setupLogout()
        setupBottomNav()
    }

    private fun initViews() {
        tvUserName = findViewById(R.id.tvUserName)
        tvUserEmail = findViewById(R.id.tvUserEmail)
        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        btnLogout = findViewById(R.id.btnLogout)
    }

    private fun loadUserData() {
        val user = auth.currentUser ?: return

        val name = user.displayName ?: "User"
        val email = user.email ?: "No Email"

        tvUserName.text = name
        tvUserEmail.text = email
        etName.setText(name)
        etEmail.setText(email)
    }

    private fun setupLogout() {
        btnLogout.setOnClickListener {
            auth.signOut()

            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }

    private fun setupBottomNav() {
        findViewById<LinearLayout>(R.id.buttonDashboard).setOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.buttonDevices).setOnClickListener {
            startActivity(Intent(this, DevicesActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.buttonReports).setOnClickListener {
            startActivity(Intent(this, ReportsActivity::class.java))
        }

        // ✅ Profile – current activity (do nothing)
    }
}
