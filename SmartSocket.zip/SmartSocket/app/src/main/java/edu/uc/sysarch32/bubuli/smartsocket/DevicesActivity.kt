package edu.uc.sysarch32.bubuli.smartsocket

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*

class DevicesActivity : Activity() {

    private lateinit var devicesContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_devices)

        setupBottomButtons()
    }

    private fun setupBottomButtons() {
        val dashboardBtn = findViewById<LinearLayout>(R.id.buttonDashboard)
        val devicesBtn = findViewById<LinearLayout>(R.id.buttonDevices)
        val reportsBtn = findViewById<LinearLayout>(R.id.buttonReports)
        val profileBtn = findViewById<LinearLayout>(R.id.buttonProfile)

        dashboardBtn.setOnClickListener {
            if (this !is DashboardActivity) {
                startActivity(Intent(this, DashboardActivity::class.java))
                finish()
            }
        }
        devicesBtn.setOnClickListener {
            if (this !is DevicesActivity) {
                startActivity(Intent(this, DevicesActivity::class.java))
                finish()
            }
        }
        reportsBtn.setOnClickListener {
            if (this !is ReportsActivity) {
                startActivity(Intent(this, ReportsActivity::class.java))
                finish()
            }
        }
        profileBtn.setOnClickListener {
            if (this !is UserActivity) {
                startActivity(Intent(this, UserActivity::class.java))
                finish()
            }
        }

        devicesContainer = findViewById(R.id.devicesContainer)

        findViewById<Button>(R.id.btnAddDevice).setOnClickListener {
            showAddDeviceDialog()
        }
    }

    private fun showAddDeviceDialog() {
        val view = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_device, null)

        val etName = view.findViewById<EditText>(R.id.etDeviceName)

        AlertDialog.Builder(this)
            .setTitle("Add Device")
            .setView(view)
            .setPositiveButton("Add") { _, _ ->
                val name = etName.text.toString().trim()
                if (name.isNotEmpty()) {
                    addDeviceCard(name)
                } else {
                    Toast.makeText(this, "Device name required", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addDeviceCard(deviceName: String) {

        val card = layoutInflater.inflate(
            R.layout.item_device_card,
            devicesContainer,
            false
        )

        val tvName = card.findViewById<TextView>(R.id.tvDeviceName)
        val tvStatus = card.findViewById<TextView>(R.id.tvStatus)
        val tvPower = card.findViewById<TextView>(R.id.tvPower)
        val switchPower = card.findViewById<Switch>(R.id.switchPower)

        tvName.text = deviceName

        // SWITCH LOGIC
        switchPower.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                tvStatus.text = "Status: Active"
                tvStatus.setTextColor(getColor(android.R.color.holo_green_dark))
                tvPower.text = "Power: 0W"
            } else {
                tvStatus.text = "Status: Off"
                tvStatus.setTextColor(getColor(android.R.color.holo_red_dark))
                tvPower.text = "Power: 0W"
            }
        }

        // DELETE ON LONG PRESS
        card.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle("Delete Device")
                .setMessage("Delete $deviceName?")
                .setPositiveButton("Yes") { _, _ ->
                    devicesContainer.removeView(card)
                }
                .setNegativeButton("No", null)
                .show()
            true
        }

        // ADD ABOVE BUTTON
        val addBtn = findViewById<Button>(R.id.btnAddDevice)
        val index = devicesContainer.indexOfChild(addBtn)
        devicesContainer.addView(card, index)
    }
}
